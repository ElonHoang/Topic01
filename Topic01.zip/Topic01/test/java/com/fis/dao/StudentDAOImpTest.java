package com.fis.dao;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentDAOImpTest {

    @Test
    void addStudent() {
    }
}