package com.fis.dao.validDAO;

public interface IValidation {
    public boolean validate(String data);
}
