package com.fis.model.sort;

import com.fis.dao.sortDAO.ISortStrategy;

public class BubbleSortStrategy implements ISortStrategy {

    public void sort(Comparable[] data, int count) {

    }
}
