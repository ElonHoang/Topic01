package com.fis.model.sort;

import com.fis.dao.sortDAO.ISortStrategy;

public class SelectionSortStrategy implements ISortStrategy {
    @Override
    public void sort(Comparable[] data, int count) {

    }
}
