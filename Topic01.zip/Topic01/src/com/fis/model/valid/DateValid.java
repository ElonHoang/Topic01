package com.fis.model.valid;

import com.fis.dao.validDAO.IValidation;

public class DateValid implements IValidation {
    @Override
    public boolean validate(String data) {
        return false;
    }
}
