package com.fis.model.valid;

import com.fis.dao.validDAO.IValidation;

public class DecimalValid implements IValidation {
    @Override
    public boolean validate(String data) {
        return false;
    }
}
